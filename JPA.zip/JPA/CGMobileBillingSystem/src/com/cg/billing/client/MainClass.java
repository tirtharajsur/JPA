package com.cg.billing.client;
public class MainClass {
	public static void main(String[] args) {
	}
}