package com.cg.billing.daoservices;

public interface CustomerDAO {

}
