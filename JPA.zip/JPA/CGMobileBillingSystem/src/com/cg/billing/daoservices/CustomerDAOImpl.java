package com.cg.billing.daoservices;

public class CustomerDAOImpl implements CustomerDAO{

}
