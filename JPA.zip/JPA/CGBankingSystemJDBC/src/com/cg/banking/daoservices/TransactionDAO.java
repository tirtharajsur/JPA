package com.cg.banking.daoservices;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public interface TransactionDAO {
	Transaction save(Account account,Transaction transaction);
	boolean update(Account account,Transaction transaction);
	Transaction findOne(Account account,int transactionId);
	List<Transaction> findAll(long accountNo);
}
